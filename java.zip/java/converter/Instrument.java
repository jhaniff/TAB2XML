package converter;

public enum Instrument {
    GUITAR, DRUMS, BASS, NONE;
}
