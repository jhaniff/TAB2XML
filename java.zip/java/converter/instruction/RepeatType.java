package converter.instruction;

public enum RepeatType {
    START, END
}
