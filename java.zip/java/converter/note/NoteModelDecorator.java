package converter.note;

public interface NoteModelDecorator {
    boolean applyTo(models.measure.note.Note noteModel);
}
