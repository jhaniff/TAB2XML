package converter;

public enum InstrumentSetting {
    GUITAR, DRUMS, BASS, AUTO;
}
