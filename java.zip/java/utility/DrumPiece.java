package utility;

public enum DrumPiece {

Bass_Drum_1,
Bass_Drum_2,
Side_Stick,
Snare,
Low_Floor_Tom,
Closed_Hi_Hat,
High_Floor_Tom,
Pedal_Hi_Hat,
Low_Tom,
Open_Hi_Hat,
Low_Mid_Tom,
Hi_Mid_Tom,
Crash_Cymbal_1,
High_Tom,
Ride_Cymbal_1,
Chinese_Cymbal,
Ride_Bell,
Tambourine,
Splash_Cymbal,
Cowbell,
Crash_Cymbal_2,
Ride_Cymbal_2,
Open_Hi_Conga,
Low_Conga

}
