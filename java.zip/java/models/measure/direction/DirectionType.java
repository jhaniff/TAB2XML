package models.measure.direction;

public class DirectionType {
    Words words;

    public void setWords(Words words) {
        this.words = words;
    }

    public Words getWords() {
        return words;
    }
}
